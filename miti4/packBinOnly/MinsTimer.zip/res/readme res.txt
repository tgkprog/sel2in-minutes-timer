you can rename tmr3.ico to tmr3a.ico 
then put a new tmr3.ico here or rename tmr1.ico or tmr2.ico use that in the app image (not window icon 
but in the image in the application that "rings" when the alarm goes off.